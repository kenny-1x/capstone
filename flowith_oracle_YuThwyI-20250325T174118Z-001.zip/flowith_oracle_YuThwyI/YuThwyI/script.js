document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    mobileMenuButton.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
    });
    
    // Close mobile menu when a link is clicked
    const mobileMenuLinks = mobileMenu.querySelectorAll('a');
    mobileMenuLinks.forEach(link => {
        link.addEventListener('click', function() {
            mobileMenu.classList.add('hidden');
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Offset for the fixed header
                const headerHeight = document.querySelector('header').offsetHeight;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Handle form submissions
    const pledgeForm = document.getElementById('pledge-form');
    if (pledgeForm) {
        pledgeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real application, you would send the form data to a server
            // For this demo, we'll just simulate a successful submission
            
            // Create success message
            const successMessage = document.createElement('div');
            successMessage.className = 'mt-4 p-4 bg-green-50 rounded-md text-green-800';
            successMessage.innerHTML = `
                <div class="flex">
                    <svg class="h-5 w-5 text-green-400 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                    </svg>
                    <p>Thank you for taking the pledge! Together, we can make a difference.</p>
                </div>
            `;
            
            // Clear the form
            pledgeForm.reset();
            
            // Add the success message
            pledgeForm.appendChild(successMessage);
            
            // Remove the success message after 5 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 5000);
        });
    }
    
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Create success message
            const successMessage = document.createElement('div');
            successMessage.className = 'mt-4 p-4 bg-green-50 rounded-md text-green-800';
            successMessage.innerHTML = `
                <div class="flex">
                    <svg class="h-5 w-5 text-green-400 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                    </svg>
                    <p>Your message has been sent! We'll get back to you soon.</p>
                </div>
            `;
            
            // Clear the form
            contactForm.reset();
            
            // Add the success message
            contactForm.appendChild(successMessage);
            
            // Remove the success message after 5 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 5000);
        });
    }
    
    // Animate statistics numbers
    const stats = document.querySelectorAll('.text-4xl.font-bold.text-blue-600');
    
    const animateValue = (element, start, end, duration) => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            
            let value = Math.floor(progress * (end - start) + start);
            
            // Add % sign if the original text contains it
            if (element.innerText.includes('%')) {
                element.innerText = `${value}%`;
            } else {
                element.innerText = element.innerText.replace(/[0-9]+/, value);
            }
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };
    
    // Intersection Observer to trigger animations when elements come into view
    const observerOptions = {
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                let finalValue;
                
                if (element.innerText.includes('%')) {
                    finalValue = parseInt(element.innerText);
                    animateValue(element, 0, finalValue, 1500);
                } else if (element.innerText.includes('in')) {
                    const parts = element.innerText.split(' ');
                    finalValue = parseInt(parts[1]);
                    animateValue(element, 0, finalValue, 1500);
                } else {
                    finalValue = parseInt(element.innerText);
                    animateValue(element, 0, finalValue, 1500);
                }
                
                // Unobserve after animating
                observer.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Observe all stat elements
    stats.forEach(stat => {
        observer.observe(stat);
    });
    
    // Prevent zooming
    window.addEventListener("wheel", (e) => {
        const isPinching = e.ctrlKey;
        if (isPinching) e.preventDefault();
    }, { passive: false });
});
